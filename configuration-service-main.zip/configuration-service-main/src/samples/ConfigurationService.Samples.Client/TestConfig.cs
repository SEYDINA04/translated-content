﻿namespace ConfigurationService.Samples.Client;

public class TestConfig
{
    public string Text { get; set; }
}